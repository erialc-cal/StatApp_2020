"""
Le code suivant réalise des prédictions selon les différents modèles implémentés,
pour chaque faisceau et type de mouvement 

Pour l'utiliser: 
1. Dans le dossier "Données", déposer :
    - un fichier `database.csv`, contenant le trafic aérien au vol à vol, sur la période de l'historique + des prévisions
	(entre autre, contenant les colonnes : Date, Faisceau, ArrDep, Mvt, PAX, PAX_FQM, Sièges Corrections_ICI, Coeff_Rempl, Coeff_Rempl_FQM)
    - un fichier `Calendrier.csv`, contenant les informations du calendrier, sur la période de l'historique + des prévisions

2. Dans ce fichier, modifier la partie à l'attention de l'utilisateur (entre ###), en renseignant :
    - les dates de l'historique
    - les horizons de prévision souhaités
    - le seuil de l'intervalle de confiance souhaité (0 si pas d'intervalle désiré)
    
Le code crée alors un dataFrame pour chaque horizon de prévision, qui contient les prédictions de nombre de passagers,  
avec l'historique, le réalisé sur la période de prévisions, et les prévisions (y compris FQM). Ces DataFrame seront dans le dossier "Prévisions".
"""

import pandas as pd
from datetime import timedelta


#######################################################################################
######################### PARTIE A MODIFIER PAR L'UTILISATEUR #########################

dateDebMod = pd.to_datetime("2008-01-01") #Date de début de l'historique (inclue)
dateFinMod = pd.to_datetime("2015-12-31") #Date de fin de l'historique (inclue) 


horizonsPrev = [7]  # horizons de prévision (en jours), par exemple : 7, 91, 365, ...
ic = 0.95   # Seuil de l'intervalle de confiance souhaité (0 pour ne pas avoir d'IC)


faisceaux = ['National', 'Schengen', 'Autre UE', 'International', 'Dom Tom']
mvts = ['Arrivée' , 'Départ']
            
#######################################################################################
#######################################################################################


from Modélisation.Modele_ARIMA import previsions_ARIMA
from Modélisation.Modele_SARIMA import previsions_SARIMA
from Modélisation.Modele_NP import previsions_NP
from Modélisation.Modele_Lasso import previsions_Lasso


if __name__ == '__main__':
    
    database = pd.read_csv("Données/database.csv",low_memory=False,decimal=',')
    database = database.astype({'Date': 'datetime64[ns]','PAX_FQM':'float','Sièges Corrections_ICI':'float','Coeff_Rempl':'float','Coeff_Rempl_FQM':'float'})
    database = database.groupby(['Date','Faisceau','ArrDep']).agg({'PAX':'sum','PAX_FQM':'sum','Sièges Corrections_ICI':'sum','Coeff_Rempl':'mean','Coeff_Rempl_FQM':'mean'}).reset_index()

    Calendrier = pd.read_csv("Données/Calendrier.csv", dayfirst = True , sep = ';' , parse_dates = ['Date'])

    histoMod = database[(database['Date']>=dateDebMod) & (database['Date']<=dateFinMod)]
    
    
    for hPrev in horizonsPrev :
        
        # on va ajouter les prévisions à l'historique précédent + sur la période de prévisions
        histoPrev = database[(database['Date']>=dateDebMod) & (database['Date']<=dateFinMod+timedelta(days = hPrev))]
            # ( sans historique précédent : histoPrev = database[(database['Date']>dateFinMod) & (database['Date']<=dateFinMod+timedelta(days = hPrev))]   )
    
        Prev_Arima = pd.DataFrame()
        Prev_Sarima = pd.DataFrame()
        Prev_NP = pd.DataFrame()
        Prev_Lasso = pd.DataFrame()

    
        for faisceau in faisceaux :
            for mvt in mvts : 
            
                histoMod_2 = histoMod[(histoMod['Faisceau']==faisceau) & (histoMod['ArrDep']==mvt)]

                # Modèle Arima :
                prev_Arima = previsions_ARIMA(histoMod_2, dateDebMod, dateFinMod, hPrev, ic)
                Prev_Arima = pd.concat([Prev_Arima, prev_Arima],ignore_index=True) 


                # Modèle Sarima :
                prev_Sarima = previsions_SARIMA(histoMod_2, dateDebMod, dateFinMod, hPrev, ic)
                Prev_Sarima = pd.concat([Prev_Sarima, prev_Sarima],ignore_index=True) 
                
                
                # Modèle Non-Paramétrique :
                prev_NP = previsions_NP(histoMod_2, Calendrier, dateDebMod, dateFinMod, hPrev, ic)
                Prev_NP = pd.concat([Prev_NP, prev_NP],ignore_index=True)   

                
                # Modèle Lasso : 
                prev_Lasso = previsions_Lasso (histoMod_2, Calendrier, dateDebMod, dateFinMod, hPrev, ic)
                Prev_Lasso = pd.concat([Prev_Lasso,prev_Lasso],ignore_index=True)
                    
                    
        # Ajout des prévisions des différents modèles à histoPrev           
        histoPrev = pd.concat([histoPrev.set_index(['Date','Faisceau','ArrDep']),
                               Prev_Arima.set_index(['Date','Faisceau','ArrDep']),
                               Prev_Sarima.set_index(['Date','Faisceau','ArrDep']),
                               Prev_NP.set_index(['Date','Faisceau','ArrDep']),
                               Prev_Lasso.set_index(['Date','Faisceau','ArrDep'])],axis=1)
        histoPrev = histoPrev.reset_index()

        histoPrev.to_csv("Prévisions/Previsions_"+str(hPrev)+"j.csv")

