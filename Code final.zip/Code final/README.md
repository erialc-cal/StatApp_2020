# Outil dynamique de prédiction du trafic aérien

Auteurs : Solène Blasco Lopez, Victor Huynh, Antonin Falher, Claire He

Ce projet propose l'implémentation des modèles ARIMA, SARIMA, Lasso et Non-Paramétrique, pour la prévision du trafic aérien journalier. 
Il propose également le calcul d'intervalles de confiance des prévisions, et dispose d'un outil de visualisation des prévisions réalisées sous PowerBi.
Ce code a été conçu pour prévoir le trafic aérien journalier, par faisceau et type de mouvement.

# Fonctionnement du code

1. Déposer dans le dossier "Données" une base `database.csv` et une base `Calendrier.csv`, contenant respectivement l'historique de trafic aérien et les informations calendaires nécéssaires aux prévisions.
Dans les deux cas, les données doivent couvrir la période utilisée comme historique et la période de prévision (afin de réaliser la comparaison entre prévisions et réalisé dans l'outil PowerBi).

2. Exécuter le fichier `__main__.py`, une fois y avoir spécifié :
- les dates correspondant au début et à la fin de l'historique dans l,
- les faisceaux et mouvements pour lesquels faire des prévisions,
- les différents horizons de prévision souhaités (les modèles seront relancés pour chaque horizon)
- et l'intervalle de confiance souhaité (0 pour ne pas avoir d'intervalle de confiance). 

L'exécution du fichier `__main__.py` créera une base de données par horizon de prévision `Prévisions_hj.csv` dans le dossier "Prévisions".
Ces bases de données contiennent à la fois historique, prévisions et intervalles de confiance.


# Fonctionnement de l'outil PowerBi :

Il est possible de mettre à jour les bases de données de l'outil PowerBi (lors de la première utilisation, il faudra surement rectifier les chemins d'accès aux bases de données).

Pour changer les paramètres des visuels (Faisceau et Type de Mouvement représentés), aller dans Accueil > Transformer les données > Modifier les paramètres

Remarque : Dans l'outil PowerBi, nous visualisation des bases sur 7, 91 et 365 jours. Il est possible de visualiser sur d'autres horizons, en modifiant simplement le chemin des bases de données utilisées (pour tous les graphiques, les codes sous-jacents ne dépendent pas de l'horizon de prévision).



# Requirements
Python3 

- All 

Seaborn 0.11.1

Pandas 1.1.3

Numpy 1.19.2
```
!pip install seaborn
!pip install numpy
!pip install pandas
!pip install datetime
```


- ARIMA/SARIMA

Pmdarima 1.15.0

Statsmodels 0.12.2
```
!pip install pmdarima
!pip install -U statsmodels
```

- Lasso

Scikit-learn 0.23.2
```
!pip install -U scikit-learn
```




